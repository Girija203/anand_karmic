<!DOCTYPE html>
<html>
<head>
    <title>{{ $subject }}</title>
</head>
<body>
    <p>{{ $messageContent }}</p>
</body>
</html>
